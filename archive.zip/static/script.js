let rpm = 0;
let speed = 0;
let fuel = 100;
let temp = 80;

function updateGauge() {
    rpm += Math.floor(Math.random() * 400) + 100;
    speed += Math.floor(Math.random() * 8) + 2;
    fuel -= 0.5;
    temp += Math.random() * 3 - 1;

    if (rpm > 8000) rpm = 0;
    if (speed > 120) speed = 0;
    
    if (fuel <= 0) fuel = 100;
    
    if (temp > 120) temp = 120;
    if (temp < 60) temp = 60;

    let rpmAngle = (rpm / 8000) * 180 - 90;
    let speedAngle = (speed / 120) * 180 - 90;

    document.getElementById("rpmNeedle").style.transform = `rotate(${rpmAngle}deg)`;
    document.getElementById("speedNeedle").style.transform = `rotate(${speedAngle}deg)`;

    document.getElementById("rpmValue").innerText = (rpm / 1000).toFixed(1) + " x1000";
    document.getElementById("speedValue").innerText = speed + " km/h";

    document.getElementById("fuelBar").style.width = fuel + "%";
    
    let tempPercentage = ((temp - 60) / 60) * 100;
    document.getElementById("tempBar").style.width = tempPercentage + "%";
    
    let tempDisplay = document.getElementById("tempValue");
    if (tempDisplay) {
        tempDisplay.innerText = Math.floor(temp) + " °C";
    }
}

setInterval(updateGauge, 1000);
